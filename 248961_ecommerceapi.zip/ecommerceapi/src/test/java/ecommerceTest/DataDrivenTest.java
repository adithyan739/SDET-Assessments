package ecommerceTest;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.EcommerceEndpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import usermodels.Models;
import utilities.DataProviders;

@Listeners(utilities.ExtentReportManager.class)
public class DataDrivenTest {
	@Test(priority = 1, dataProvider = "data", dataProviderClass = DataProviders.class)
	public void testPost(String id, String name, String price, String description) {
		RestAssured.useRelaxedHTTPSValidation();
		Models user = new Models();

		user.setName(name);
		user.setPrice(price);
		user.setDescription(description);

		Response response = EcommerceEndpoints.createUser(user);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 201);
	}

	@Test(priority = 2, dataProvider = "idData", dataProviderClass = DataProviders.class)
	public void testGetById(String id) {
		Response response = EcommerceEndpoints.getUser(Integer.parseInt(id));
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
	}

	@Test(priority = 3, dataProvider = "idData", dataProviderClass = DataProviders.class)
	public void testUpdateById(String id) {
		Models user = new Models();
		user.setName("Watch");
		user.setPrice("1500");
		user.setDescription("Honor");
		Response response = EcommerceEndpoints.updateUser(Integer.parseInt(id), user);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
	}

	@Test(priority = 4, dataProvider = "idData", dataProviderClass = DataProviders.class)
	public void testDeleteById(String id) {
		Response response = EcommerceEndpoints.deleteUser(Integer.parseInt(id));
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 204);
	}
}
