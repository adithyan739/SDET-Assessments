package testcase;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.assertj.core.api.SoftAssertions;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.BaseTest;
import page.GeneralStorePage;

@Listeners(utilities.SampleListener.class)
public class GeneralStoreTest extends BaseTest{
	@DataProvider(name = "getData")
	public Object[][] getData() throws IOException {
		List<HashMap<String, String>> data = getJsonData(
				System.getProperty("user.dir") + "\\src\\test\\java\\testdata\\data.json");
		Object[][] testData = new Object[data.size()][5];
		for (int i = 0; i < data.size(); i++) {
			HashMap<String, String> row = data.get(i);
			testData[i][0] = row.get("name");
			testData[i][1] = row.get("gender");
			testData[i][2] = row.get("country");
			testData[i][3] = row.get("product");
			testData[i][4] = row.get("price");
		}
		return testData;
	}
	
	@Test(dataProvider = "getData")
	public void storeTest(String name,String gender,String country,String product,String price) {
		GeneralStorePage gs=new GeneralStorePage(driver);
		gs.clickCountry();
		gs.scrollCountry(country);
		gs.inpName(name);
		gs.selectGender(gender);
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(gs.isletsshopbtn()).isTrue();
		});
		gs.clickLetsShop();	
		
		String expproduct = product;
		String actualproduct = gs.getProductText();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expproduct.equalsIgnoreCase(actualproduct)).isTrue();
		});
		gs.clickAddtoCart();
		gs.clickViewCart();
		
		String expproductprice = price;
		String actualproductprice = gs.getproductPrice();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expproductprice.equalsIgnoreCase(actualproductprice)).isTrue();
		});
		
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(gs.isProceedbtn()).isTrue();
		});
		gs.clickProceed();
	}
}
