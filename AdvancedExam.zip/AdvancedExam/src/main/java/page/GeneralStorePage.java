package page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import base.AndroidActions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class GeneralStorePage extends AndroidActions {
	private AndroidDriver driver;

	public GeneralStorePage(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@AndroidFindBy(id = "com.androidsample.generalstore:id/spinnerCountry")
	private WebElement country;

	@AndroidFindBy(id = "com.androidsample.generalstore:id/nameField")
	private WebElement name;

	@AndroidFindBy(id = "com.androidsample.generalstore:id/radioMale")
	private WebElement male;

	@AndroidFindBy(id = "com.androidsample.generalstore:id/radioFemale")
	private WebElement female;

	@AndroidFindBy(id = "com.androidsample.generalstore:id/btnLetsShop")
	private WebElement btnLetsShop;

	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.RelativeLayout/android.widget.FrameLayout/android.support.v7.widget.RecyclerView/android.widget.RelativeLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout[2]/android.widget.TextView[2]")
	private WebElement addtoCart;

	@AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.RelativeLayout/android.widget.FrameLayout/android.support.v7.widget.RecyclerView/android.widget.RelativeLayout[1]/android.widget.LinearLayout/android.widget.LinearLayout[2]/android.widget.TextView[2]")
	private WebElement addtoCart1;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Air Jordan 1 Mid SE']")
	private WebElement airJordan;

	@AndroidFindBy(xpath = "//android.widget.TextView[@text='Air Jordan 4 Retro']")
	private WebElement airJordanretro;

	@AndroidFindBy(id = "com.androidsample.generalstore:id/appbar_btn_cart")
	private WebElement btncart;

	@AndroidFindBy(id = "com.androidsample.generalstore:id/productPrice")
	private WebElement productprice;

	@AndroidFindBy(id = "com.androidsample.generalstore:id/btnProceed")
	private WebElement btnProceed;

	public void clickCountry() {
		country.click();
	}

	public void scrollCountry(String cn) {
		scrollToTextAndClick(cn);
	}

	public void inpName(String nm) {
		name.sendKeys(nm);
	}

	public void selectGender(String gender) {
		if (gender.contains("Male"))
			male.click();
		else
			female.click();
	}


	public void clickLetsShop() {
		btnLetsShop.click();
	}

	public String getProductText() {
		return airJordan.getText();
	}

	public String getProduct1Text() {
		return airJordanretro.getText();
	}

	public void clickAddtoCart() {
		addtoCart.click();
	}

	public void clickAddtoCart1() {
		addtoCart1.click();
	}

	public void clickViewCart() {
		btncart.click();
	}

	public String getproductPrice() {
		return productprice.getText();
	}

	public void clickProceed() {
		btnProceed.click();
	}

	public boolean isProceedbtn() {
		return btnProceed.isDisplayed();
	}

	public boolean isletsshopbtn() {
		return btnLetsShop.isDisplayed();
	}

}
