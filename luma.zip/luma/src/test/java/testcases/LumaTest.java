package testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.BaseUI;
import pom.Luma;
@Listeners(utilities.ListenerUtils.class)
public class LumaTest extends BaseUI {
	WebDriver driver;

	//method for invoking browser
	@BeforeTest
	public void setup() {
		driver = invokebrowser();
		openBrowser("applicationURL");

	}
	
	//method for doing backpack search tests
	@Test(priority = 1)
	public void lumaTest() {
		Luma lm = new Luma(driver);
		lm.searchElement("backpack");
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("search")).isDisplayed());
		});
		lm.searchIcon();
		String actualURL = lm.getURL();
		String expURL = "https://magento.softwaretestingboard.com/catalogsearch/result/?q=backpack";
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualURL.equalsIgnoreCase(expURL)).isTrue();

		});

	}

	//method for doing backpack sort tests
	@Test(priority = 2)
	public void backpackSort() {
		Luma lm = new Luma(driver);
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.xpath("//button[@title='Search']")).isDisplayed());
		});
		lm.sortClick();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(driver.findElement(By.id("sorter")).isDisplayed());
		});
		lm.dropSelect("Price");

	}
	
	//method for doing backpack click tests
	@Test(priority=3)
	public void backpackClickTest() {
		Luma lm = new Luma(driver);
		lm.backpackClick();
		String actualURL = lm.getURL();
		String expURL = "https://magento.softwaretestingboard.com/fusion-backpack.html";
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualURL.equalsIgnoreCase(expURL)).isTrue();

		});
	}
	
	
}
