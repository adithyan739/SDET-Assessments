$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"eb3e5e7b-f367-47a5-a6b8-31870f23fc67","feature":"Luma page feature","scenario":"Luma page title","start":1691649924533,"group":1,"content":"","tags":"","end":1691649937574,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});