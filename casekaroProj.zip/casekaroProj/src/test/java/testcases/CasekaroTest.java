package testcases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.BaseUI;
import pom.CasekaroCart;
import pom.CasekaroLogin;
import pom.CasekaroSign;
import utilities.Excelutils;

public class CasekaroTest extends BaseUI{
	WebDriver driver;
	String[][] data;
	
//	@DataProvider(name = "testData")
//	public Object[][] testData() {
//		data = Excelutils.testdata();
//		return data;
//	}

	@BeforeMethod
	public void setup() {
		driver = invokebrowser();
		openBrowser("applicationURL");
	}
	
//	@Test(priority=0)
//	public void signUp() {
//		CasekaroSign cas=new CasekaroSign(driver);
//		cas.loginClick();
//		cas.regClick();
//		cas.firstname("adhith");
//		cas.lastname("k");
//		cas.emailText("adhith@gmail.com");
//		cas.passWord("adhit*1");
//		cas.createbtn();
//		cas.captchaClick();
//	}
//	
	@Test(priority=0)
	public void login() {
		CasekaroLogin cas=new CasekaroLogin(driver);
		cas.loginClick();
		cas.customerEmail("adhi@gmail.com");
		cas.customerPassword("adhi*1");
		cas.signBtn();
	}
	
	@Test(priority=1)
	public void coverCart() {
		CasekaroCart cas=new CasekaroCart(driver);
		cas.mobCoverClick();
	}

}
