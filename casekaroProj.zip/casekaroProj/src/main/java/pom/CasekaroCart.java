package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.BaseUI;

public class CasekaroCart extends BaseUI{
	WebDriver driver;

	public CasekaroCart(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//a[@href='https://casekaro.com/pages/mobile-back-covers']")
	WebElement mobCover;
	
	public void mobCoverClick() {
		clickOn(mobCover);
	}
	
	
	

}
