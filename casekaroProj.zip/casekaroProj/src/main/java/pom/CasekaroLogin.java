package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.BaseUI;

public class CasekaroLogin extends BaseUI{
	WebDriver driver;

	 public CasekaroLogin(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	 
	 @FindBy(xpath="//a[@href='/account/login']")
	 WebElement login;
	 
	 @FindBy(id="CustomerEmail")
	 WebElement custEmail;
	 
	 @FindBy(id="CustomerPassword")
	 WebElement custPass;
	 
	 @FindBy(xpath="//input[@value='Sign In']")
	 WebElement sign;
	 
	 public void loginClick() {
		 clickOn(login);
	 }
	 
	 public void customerEmail(String email) {
		 sendtext(custEmail,email);
	 }
	 
	 public void customerPassword(String pass) {
		 sendtext(custPass,pass);
	 }
	 
	 public void signBtn() {
		 clickOn(sign);
	 }

}
