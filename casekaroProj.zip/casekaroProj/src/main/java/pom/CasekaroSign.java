package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.BaseUI;

public class CasekaroSign extends BaseUI{
	WebDriver driver;

	 public CasekaroSign(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	 
	 @FindBy(xpath="//a[@href='/account/login']")
	 WebElement login;
	 
	 @FindBy(id="customer_register_link")
	 WebElement register;
	 
	 @FindBy(id="FirstName")
	 WebElement firstname;
	 
	 @FindBy(id="LastName")
	 WebElement lastname;
	 
	 @FindBy(id="Email")
	 WebElement email;
	 
	 @FindBy(id="CreatePassword")
	 WebElement password;
	 
	 @FindBy(xpath="//input[@type='submit']")
	 WebElement create;
	 
	 @FindBy(xpath="//*[@id=\"recaptcha-anchor\"]/div[1]")
	 WebElement captcha;
	 
	 public void loginClick() {
		 clickOn(login);
	 }
	 
	 public void regClick() {
		 clickOn(register);
	 }
	 
	 public void firstname(String fname) {
		 sendtext(firstname,fname);
	 }
	 
	 public void lastname(String lname) {
		 sendtext(lastname,lname);
	 }
	 
	 public void emailText(String emai) {
		 sendtext(email, emai);
	 }
	 
	 public void passWord(String pass) {
		 sendtext(password, pass);
	 }
	 
	 public void createbtn() {
		 clickOn(create);
	 }
	 public void captchaClick() {
		 clickOn(captcha);
	 }

}
