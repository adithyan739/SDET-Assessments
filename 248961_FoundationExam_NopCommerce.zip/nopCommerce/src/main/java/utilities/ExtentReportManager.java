package utilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import base.BaseUI;

public class ExtentReportManager extends BaseUI {
	public static ExtentReports extent;
	public static ExtentSparkReporter spark;

	public static ExtentReports getReportInstance() {
		extent = new ExtentReports();
		String repName = "TestReport-" + BaseUI.timestamp + ".html";
		spark = new ExtentSparkReporter(System.getProperty("user.dir") + "/TestOutput/" + repName);
		extent.attachReporter(spark);
		extent.setSystemInfo("Host Name", "UST");
		extent.setSystemInfo("Environment", "Production");
		extent.setSystemInfo("User Name", "Adhi");
		spark.config().setDocumentTitle("NopCommerce Report");
		spark.config().setReportName("NopCommerceDemo Report");// Name of the report
		spark.config().setTheme(Theme.DARK);// Dark Theme
		return extent;
	}
}
