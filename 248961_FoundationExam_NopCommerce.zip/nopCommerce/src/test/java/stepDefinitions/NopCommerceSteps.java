package stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import base.BrowserConfig;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.NopCommerce;


public class NopCommerceSteps {
	public static String title;
	public WebDriver driver=BrowserConfig.getBrowser();
	public NopCommerce l=new NopCommerce(driver);
	
	@Given("user is on login page")
	public void user_is_on_login_page() {
		driver.get("https://demo.nopcommerce.com/");
	}
	@When("user gets the title of  page")
	public void user_gets_the_title_of_page() {
		title=l.getTitle();
		System.out.println(title);
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String string) {
		title=l.getTitle();
		Assert.assertEquals(title,string);
	}

	@When("user clicks on login")
	public void user_clicks_on_login() {
		l.login();
	}

	@When("user enters email {string}")
	public void user_enters_email(String string) {
	    l.email(string);
	}

	@When("user enters password {string}")
	public void user_enters_password(String string) {
	   l.password(string);
	}

	@When("user clicks on submit button")
	public void user_clicks_on_submit_button() {
	   l.submit();
	}
	
}
