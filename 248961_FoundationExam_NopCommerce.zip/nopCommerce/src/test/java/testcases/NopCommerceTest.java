package testcases;

import org.assertj.core.api.SoftAssertions;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.BaseUI;
import pom.NopCommerce;
import utilities.Excelutils;
import utilities.Excelutils2;

@Listeners(utilities.SampleListener.class)
public class NopCommerceTest extends BaseUI {
	WebDriver driver;
	NopCommerce log;
	String[][] data;

	// Method for calling the browser
	@BeforeMethod
	public void setup() {
		driver = invokebrowser();
		openBrowser("applicationURL");
	}

	// Method to get the register value from excel
	@DataProvider(name = "testdata")
	public Object[][] testdata() {
		data = Excelutils.testdata();
		return data;

	}

	// Method to get the login value from excel
	@DataProvider(name = "testdata1")
	public Object[][] testdata1() {
		data = Excelutils2.testdata();
		return data;

	}

	// Method to perform register
	@Test(priority = 1, dataProvider = "testdata")
	public void register(String firstname, String lastname, String mail, String password, String confPass) {
		NopCommerce log = new NopCommerce(driver);
		log.registerClick();
		String actualURL = log.getURL();
		String expURL = "https://demo.nopcommerce.com/register?returnUrl=%2F";
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualURL.equalsIgnoreCase(expURL)).isTrue();

		});

		log.firstName(firstname);
		log.lastName(lastname);
		log.email1(mail);
		log.password1(password);
		log.confirmPas(confPass);
		log.register();

	}

	// Method to perform login and assertions
	@Test(priority = 2, dataProvider = "testdata1")
	public void loginTest(String email, String password) {
		String a = "https://demo.nopcommerce.com/";
		driver.get(a);

		NopCommerce log = new NopCommerce(driver);
		log.login();
		String actualURL = log.getURL();
		String expURL = "https://demo.nopcommerce.com/login?returnUrl=%2F";
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualURL.equalsIgnoreCase(expURL)).isTrue();

		});

		log.email(email);
		log.password(password);
		log.submit();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(a.contains("https://demo.nopcommerce.com/"));
		});

		String e = log.errorm();
		if ((email.equals("IncorrectUser"))) {

			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(
						e.equalsIgnoreCase("Login was unsuccessful. Please correct the errors and try again.\r\n"
								+ "No customer account found"));
			});
		} else if (password.equals(" ")) {
			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(
						e.equalsIgnoreCase("Login was unsuccessful. Please correct the errors and try again.\r\n"
								+ "No customer account found"));
			});
		} else {

			SoftAssertions.assertSoftly(softAssertions -> {
				softAssertions.assertThat(a.contains("https://demo.nopcommerce.com/"));
			});

		}

	}

	// method to perform add a product to cart
	@Test(priority = 3)
	public void productSelect() {

		NopCommerce log = new NopCommerce(driver);
		log.electronics();
		String actualURL = log.getURL();
		String expURL = "https://demo.nopcommerce.com/electronics";
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(actualURL.equalsIgnoreCase(expURL));

		});
		
		log.cameraphotoClick();
		log.nikonClick();
		log.cartClick();
	}

}
