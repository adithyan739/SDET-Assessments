$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"b679b1a9-accb-470a-99be-ed86f36da21b","feature":"Login page feature","scenario":"Login page title","start":1692944976996,"group":1,"content":"","tags":"","end":1692944986244,"className":"passed"},{"id":"18ee1386-e15c-42db-8bed-45af428b4073","feature":"Login page feature","scenario":"Login with correct credentials","start":1692944986265,"group":1,"content":"","tags":"","end":1692944993129,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});