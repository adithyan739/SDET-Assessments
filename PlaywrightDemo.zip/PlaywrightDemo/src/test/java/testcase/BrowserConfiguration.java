package testcase;


import org.testng.annotations.Test;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class BrowserConfiguration {
	@Test
	public void browserConfig() {
		try {
			Playwright playwright=Playwright.create();
			Browser browser=playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false).setSlowMo(50));
			Page page=browser.newPage();
			page.navigate("https://www.mycontactform.com/");
			System.out.println(page.title());
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}
