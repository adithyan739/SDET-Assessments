package Base;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;

public class BaseTestChrome {
public AndroidDriver driver;
	
	@BeforeMethod
	public void setup() throws MalformedURLException {
		DesiredCapabilities capabilities=new DesiredCapabilities();
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UiAutomator2");
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Adhiphone1");
		capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, "com.android.chrome");
		capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, "com.google.android.apps.chrome.Main");
		driver=new AndroidDriver(new URL("http://127.0.0.1:4723/"),capabilities);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
}
