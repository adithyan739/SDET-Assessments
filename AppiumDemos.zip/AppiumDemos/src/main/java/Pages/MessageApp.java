package Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import Base.BaseTest;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class MessageApp{
	
	private AndroidDriver driver;
	public MessageApp(AndroidDriver driver) {
		this.driver=driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	
	@AndroidFindBy(uiAutomator= "new UiSelector().text(\"Got it\")")
	private WebElement gotit;
	
	@AndroidFindBy(accessibility = "Start chat")
	private WebElement startchat;
	
	@AndroidFindBy (id="com.google.android.apps.messaging:id/recipient_text_view")
	private WebElement innum;
	
	@AndroidFindBy (id="com.google.android.apps.messaging:id/compose_message_text")
	private WebElement inmsg;
	
	@AndroidFindBy(accessibility = "Send SMS")
	private WebElement sendmsg;
	
	public void clickGotit() {
		gotit.click();
	}
	
	public void clickStartchat() {
		startchat.click();
	}
	
	public void inputNum(String num) {
		innum.sendKeys(num);
	}
	
	public void inputMsg(String ms) {
		inmsg.sendKeys(ms);
	}
	
	public void clickSendmsg() {
		sendmsg.click();
	}

	
}
