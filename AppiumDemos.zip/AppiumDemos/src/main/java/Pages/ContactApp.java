package Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class ContactApp {
	private AndroidDriver driver;
	public ContactApp(AndroidDriver driver) {
		this.driver=driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@AndroidFindBy (id="android:id/button2")
	private WebElement skip;
	
	@AndroidFindBy (id="com.android.permissioncontroller:id/permission_allow_button")
	private WebElement allow;
	
	@AndroidFindBy (accessibility = "Create contact")
	private WebElement createcontact;
	
	@AndroidFindBy (xpath = "//android.widget.EditText[@text='First name']")
	private WebElement firstname;
	
	@AndroidFindBy (xpath = "//android.widget.EditText[@text='Last name']")
	private WebElement lastname;
	
	@AndroidFindBy (xpath = "//android.widget.EditText[@text='Company']")
	private WebElement company;
	
	@AndroidFindBy (xpath = "//android.widget.EditText[@text='Phone']")
	private WebElement phone;
	
	@AndroidFindBy (xpath = "//android.widget.EditText[@text='Email']")
	private WebElement email;
	
	@AndroidFindBy (id="com.google.android.contacts:id/toolbar_button")
	private WebElement save;
	
	public void clickSkip() {
		skip.click();
	}
	
	public void clickAllow() {
		allow.click();
	}
	
	public void clickCreate() {
		createcontact.click();
	}
	
	public void firstName(String fname) {
		firstname.sendKeys(fname);
	}
	
	public void lastName(String lname) {
		lastname.sendKeys(lname);
	}
	
	public void company(String cmp) {
		company.sendKeys(cmp);
	}
	
	public void phone(String phn) {
		phone.sendKeys(phn);
	}
	
	public void email(String em) {
		email.sendKeys(em);
	}
	
	public void clickSave() {
		save.click();
	}
	
	public boolean isFirstnameFieldPresent() {
		return firstname.isDisplayed();
	}
}
