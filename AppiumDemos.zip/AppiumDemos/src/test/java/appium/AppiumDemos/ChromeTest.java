package appium.AppiumDemos;

import org.testng.annotations.Test;

import Base.BaseTestChrome;
import Pages.ChromeApp;
import io.appium.java_client.AppiumBy;

public class ChromeTest extends BaseTestChrome {

	@Test
	public void chromeTest() {
		
		ChromeApp chrome=new ChromeApp(driver);
		chrome.clickAccept();
	}
}
