package appium.AppiumDemos;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.MobileCapabilityType;

public class MessageAppActivity {
	public AndroidDriver driver;
	
	@Test
	public void test() throws MalformedURLException {
		DesiredCapabilities capabilities=new DesiredCapabilities();
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UiAutomator2");
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Adhiphone1");
		capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, "com.google.android.apps.messaging");
		capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, "com.google.android.apps.messaging.ui.ConversationListActivity");
		driver=new AndroidDriver(new URL("http://127.0.0.1:4723/"),capabilities);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().text(\"Got it\")")).click();
		driver.findElement(AppiumBy.accessibilityId("Start chat")).click();
		driver.findElement(AppiumBy.id("com.google.android.apps.messaging:id/recipient_text_view")).sendKeys("7558802443");
		driver.executeScript("mobile: performEditorAction", ImmutableMap.of("action","Go"));
		//driver.findElement(AppiumBy.id("com.google.android.apps.messaging:id/contact_picker_create_group")).click();
		
		driver.findElement(AppiumBy.id("com.google.android.apps.messaging:id/compose_message_text")).sendKeys("Hi,Hello");
		driver.findElement(AppiumBy.accessibilityId("Send SMS")).click();
	}

}
