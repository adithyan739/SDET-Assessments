package testcase;

import org.testng.annotations.Test;

import com.google.common.collect.ImmutableMap;

import Base.BaseTest;
import Pages.MessageApp;

public class MessageTest extends BaseTest{
@Test
	public void test() {
		MessageApp msg=new MessageApp(driver);
		msg.clickGotit();
		msg.clickStartchat();
		msg.inputNum("7558802441");
		driver.executeScript("mobile: performEditorAction", ImmutableMap.of("action","Go"));
		msg.inputMsg("Hi, Adhi");
		msg.clickSendmsg();
		
	}
}
