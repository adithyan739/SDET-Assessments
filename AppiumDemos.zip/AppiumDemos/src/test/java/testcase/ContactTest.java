package testcase;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.assertj.core.api.SoftAssertions;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Base.BaseTestContact;
import Pages.ContactApp;
//@Listeners(Utilities.SampleListener.class)
public class ContactTest extends BaseTestContact {
	@DataProvider(name = "getData")
	public Object[][] getData() throws IOException {
		List<HashMap<String, String>> data = getJsonData(
				System.getProperty("user.dir") + "\\src\\test\\java\\testdata\\data.json");
		Object[][] testData = new Object[data.size()][5];
		for (int i = 0; i < data.size(); i++) {
			HashMap<String, String> row = data.get(i);
			testData[i][0] = row.get("firstname");
			testData[i][1] = row.get("lastname");
			testData[i][2] = row.get("company");
			testData[i][3] = row.get("phone");
			testData[i][4] = row.get("email");
		}
		return testData;
	}
	@Test(dataProvider = "getData")
	public void contactTest(String fname,String lname,String company,String phone,String email) {
		ContactApp contact=new ContactApp(driver);
		contact.clickSkip();
		contact.clickAllow();
		contact.clickCreate();
		SoftAssertions.assertSoftly(softAssertions -> {
			 softAssertions.assertThat(contact.isFirstnameFieldPresent()).isTrue();
			 });
		contact.firstName(fname);
		contact.lastName(lname);
		contact.company(company);
		contact.phone(phone);
		contact.email(email);
		contact.clickSave();
		
		
	}

}
