package testcase;

import org.testng.annotations.Test;

import com.google.common.collect.ImmutableMap;

import Base.BaseTestChrome;
import Pages.ChromeApp;
import io.appium.java_client.AppiumBy;

public class ChromeTest extends BaseTestChrome {

	@Test
	public void chromeTest() {
		
		ChromeApp chrome=new ChromeApp(driver);
		chrome.clickAccept();
		chrome.clicknoThanks();
		chrome.clicknoThanks1();
		chrome.inSearch("mycontactform.com");
		driver.executeScript("mobile: performEditorAction", ImmutableMap.of("action","Go"));
	}
}
