package testcases;

import org.assertj.core.api.SoftAssertions;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.GeneralStore;

public class GeneralStoreTest extends BaseTest{
	
	@Test
	public void test() {
		GeneralStore gstore=new GeneralStore(driver);
		gstore.clickCountryScroll();
		gstore.scrollCountry("Argentina");
		gstore.enterName("Adhi");
		gstore.clickLetsShop();
		gstore.scrollProduct("Air Jordan 9 Retro");
		gstore.clickAddtoCart1();
		gstore.scrollProduct("PG 3");
		gstore.clickAddtoCart2();
		gstore.cickViewAddtoCart();
		String expprice = "$170.97";
		String actualprice = gstore.getProductprice1();
		SoftAssertions.assertSoftly(softAssertions -> {
			softAssertions.assertThat(expprice.equalsIgnoreCase(actualprice)).isTrue();
		});
		
//		String expprice1 = "$110.0";
//		String actualprice1 = gstore.getProductprice2();
//		SoftAssertions.assertSoftly(softAssertions -> {
//			softAssertions.assertThat(expprice1.equalsIgnoreCase(actualprice1)).isTrue();
//		});
		gstore.clickProceed();
	}
}
