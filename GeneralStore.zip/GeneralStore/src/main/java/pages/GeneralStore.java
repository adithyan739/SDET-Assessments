package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import base.AndroidActions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class GeneralStore extends AndroidActions{
	private AndroidDriver driver;

	public GeneralStore(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@AndroidFindBy(id="com.androidsample.generalstore:id/spinnerCountry")
	private WebElement country;
	
	@AndroidFindBy(id="com.androidsample.generalstore:id/nameField")
	private WebElement name; 
	
	@AndroidFindBy(id="com.androidsample.generalstore:id/btnLetsShop")
	private WebElement letsshopbtn;

	@AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.RelativeLayout/android.widget.FrameLayout/android.support.v7.widget.RecyclerView/android.widget.RelativeLayout[3]/android.widget.LinearLayout/android.widget.LinearLayout[2]/android.widget.TextView[2]")
	private WebElement addtocart1;
	
	@AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.RelativeLayout/android.widget.FrameLayout/android.support.v7.widget.RecyclerView/android.widget.RelativeLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout[2]/android.widget.TextView[2]")
	private WebElement addtocart2;
	
	@AndroidFindBy(id="com.androidsample.generalstore:id/appbar_btn_cart")
	private WebElement viewaddtocart;
	
	@AndroidFindBy(id="com.androidsample.generalstore:id/btnProceed")
	private WebElement proceedbtn;
	
	@AndroidFindBy(id="com.androidsample.generalstore:id/productPrice")
	private WebElement productprice1;
	
	@AndroidFindBy(xpath="/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.RelativeLayout/android.widget.RelativeLayout/android.support.v7.widget.RecyclerView/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout[2]/android.widget.TextView")
	private WebElement productprice2;
	
	public void clickCountryScroll() {
		country.click();
	}
	
	public void scrollCountry(String cn) {
		 scrollToText(cn);
	}
	
	public void enterName(String nme) {
		name.sendKeys(nme);
	}
	
	public void clickLetsShop() {
		letsshopbtn.click();
	}
	
	public void scrollProduct(String pd) {
		 scrollToText(pd);
	}
	
	public void clickAddtoCart1() {
		addtocart1.click();
	}
	
	public void clickAddtoCart2() {
		addtocart2.click();
	}
	
	public void cickViewAddtoCart() {
		viewaddtocart.click();
	}
	
	public String getProductprice1() {
		return productprice1.getText();
	}
	
	public String getProductprice2() {
		return productprice2.getText();
	}

	public void clickProceed() {
		proceedbtn.click();
	}
}
