package testcases;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.CoverphotoEndPoints;
import endpoints.Routes;
import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import payload.CoverphotoModel;
import utilities.DataProviders;

@Listeners(utilities.ExtentReportManager.class)
public class DataDrivenTest {
	//test method for creating coverphoto
	@Test(priority = 1, dataProvider = "data", dataProviderClass = DataProviders.class)
	public void testPostCoverphoto(String id, String idBook, String url) {
		RestAssured.useRelaxedHTTPSValidation();
		CoverphotoModel cover = new CoverphotoModel();
		cover.setId(Integer.parseInt(id));
		cover.setIdBook(idBook);
		cover.setUrl(url);

		Response response = CoverphotoEndPoints.createCoverphoto(cover);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
	}
	
	//test method for getting coverphoto by Id
	@Test(priority = 2, dataProvider = "idData", dataProviderClass = DataProviders.class)
	public void testGetCoverphotoByid(String id) {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = CoverphotoEndPoints.getCoverphoto(Integer.parseInt(id));
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
	}

	//test method for updating coverphoto by id
	@Test(priority = 3, dataProvider = "updateData", dataProviderClass = DataProviders.class)
	public void testUpdateCoverphotoById(String id, String idBook, String url) {
		RestAssured.useRelaxedHTTPSValidation();
		CoverphotoModel cover = new CoverphotoModel();
		cover.setId(Integer.parseInt(id));
		cover.setIdBook(idBook);
		cover.setUrl(url);
		Response response = CoverphotoEndPoints.updateCoverphoto(Integer.parseInt(id), cover);
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
	}

	//test method for deleting coverphoto by id
	@Test(priority = 4, dataProvider = "idData", dataProviderClass = DataProviders.class)
	public void testDeleteByCoverphotoId(String id) {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = CoverphotoEndPoints.deleteCoverphoto(Integer.parseInt(id));
		response.then().log().all();
		Assert.assertEquals(response.getStatusCode(), 200);
	}
	
	//schema validation
	@Test(priority = 5)
    public void schemavalidation() {
    	String url="https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos";
    	RestAssured.given()
        .when()
        .get(url)
        .then()
        .assertThat()
        .body(JsonSchemaValidator.matchesJsonSchema(System.getProperty("user.dir") + "\\src\\test\\resources\\cover.json"));
    }

}
