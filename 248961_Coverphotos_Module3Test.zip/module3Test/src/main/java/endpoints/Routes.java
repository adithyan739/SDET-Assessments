package endpoints;

public class Routes {
	public static String baseuri="https://fakerestapi.azurewebsites.net/api/v1";
	public static String get_basePath="/CoverPhotos/{id}";
	public static String post_basePath="/CoverPhotos";
	public static String put_basePath="/CoverPhotos/{id}";
	public static String delete_basePath="/CoverPhotos/{id}";
}
