package endpoints;

public class Routes {
	public static String baseuri="http://localhost:8080";
	public static String post_basePath="/products";
	public static String get_basePath="/products/{id}";
	public static String delete_basePath="/products/{id}";
	public static String update_basePath="/products/{id}";
}
