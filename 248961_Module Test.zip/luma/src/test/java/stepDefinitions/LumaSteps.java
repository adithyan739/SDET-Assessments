package stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import base.BrowserConfig;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.Luma;


public class LumaSteps {
	public static String title;
	public WebDriver driver=BrowserConfig.getBrowser();
	public Luma lm=new Luma(driver);
	@Given("user is on Luma page")
	public void user_is_on_luma_page() {
	    driver.get("https://magento.softwaretestingboard.com/");
	}

	@When("user gets the title of the page")
	public void user_gets_the_title_of_the_page() {
		title = lm.getLoginPageTitle();
		System.out.println("Home Page" + title);
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String string) {
		Assert.assertTrue(title.contains(string));
	}
}
