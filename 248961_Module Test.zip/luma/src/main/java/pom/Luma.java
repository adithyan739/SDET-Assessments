package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.BaseUI;

public class Luma extends BaseUI{
	WebDriver driver;
	public Luma(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(id = "search")
	WebElement search;
	
	@FindBy(xpath = "//button[@title='Search']")
	WebElement searchbtn;
	
	@FindBy(id = "sorter")
	WebElement sort;
	
	@FindBy(linkText = "Fusion Backpack")
	WebElement backpack;
	
	//send text to search element
	public void searchElement(String txt) {
		sendtext(search, txt);
	}
	
	//enter the value 
	public void searchIcon() {
		Enter(searchbtn);
	}
	
	//get url of the page
	public String getURL() {
		String url = driver.getCurrentUrl();
		return url;
	}
	
	//click sort button
	public void sortClick() {
		clickOn(sort);
	}
	
	//dropdown select
	public void dropSelect(String sel) {
		dropDownHandling(sort, sel);
	}
	
	//get title of the page
	public String getLoginPageTitle() {
		return driver.getTitle();
	}
	
	//click on backpack
	public void backpackClick() {
		clickOn(backpack);
	}
}
